// loading
$(document).ready(function() {
 
  // Fakes the loading setting a timeout
    setTimeout(function() {
        $('body').addClass('loaded');
    }, 3500);
 
});
// loading

//$(document).ready(function(){//
//$("body").trigger("click");//
 // $("a.link").hover(//
  //function() {//
    //alert("arabicps4games.com");//
    //location.href="https://arabicps4games.com";//
  //}//
//);//
   
 // $(document).on('keydown',function(event)//
    //{//
     //alert(event.which);//
    //if(event.keyCode==123)//
    //{//
        //alert('Developers arabicps4games.com');
        //$("body").html("<h1>arabicps4games.com</h1>");
      //event.preventDefault();
        //return false;
    //}//
    //else if(event.ctrlKey && event.shiftKey && event.keyCode==73)//
    //{//
      
        //alert('No Developers Tools')//
      //event.preventDefault();//
        //return false;  //Prevent from ctrl+shift+i//
    //}//
    //else if(event.ctrlKey && event.keyCode==74)//
    //{//
        //alert('Entered ctrl+shift+j')//
        //event.preventDefault();//
        //return false;  //Prevent from ctrl+shift+i//
    //}//
//});//
//$(document).on("contextmenu",function(e)//
//{//
//alert('Right Click Not Allowed')//
//e.preventDefault();//
//});//
  
//});//